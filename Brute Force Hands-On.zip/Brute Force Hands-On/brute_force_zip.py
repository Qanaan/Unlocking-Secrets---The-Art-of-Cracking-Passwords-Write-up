import zipfile
import itertools
import string
import os
import tempfile

def brute_force_zip(zip_path, target_file=None, max_length=3):
    """
    Brute force a password-protected ZIP file.
    
    Args:
        zip_path: Path to the ZIP file
        target_file: Specific file to extract (optional)
        max_length: Maximum password length to try
    """
    if not os.path.exists(zip_path):
        print(f"[-] ZIP file not found: {zip_path}")
        return None
    
    chars = string.ascii_letters + string.digits  # a-zA-Z0-9
    total_attempts = sum(len(chars) ** i for i in range(1, max_length + 1))
    attempt_count = 0
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            # List files in the ZIP if target_file not specified
            if target_file is None:
                print("[*] Files in ZIP:")
                for file_info in zf.filelist:
                    print(f"    {file_info.filename}")
                target_file = zf.filelist[0].filename  # Use first file
                print(f"[*] Using first file for testing: {target_file}")
            
            # Check if target file exists in ZIP
            try:
                zf.getinfo(target_file)
            except KeyError:
                print(f"[-] File '{target_file}' not found in ZIP")
                print("[*] Available files:")
                for file_info in zf.filelist:
                    print(f"    {file_info.filename}")
                return None
            
            print(f"[*] Starting brute force attack...")
            print(f"[*] Target file: {target_file}")
            print(f"[*] Max password length: {max_length}")
            print(f"[*] Total combinations to try: {total_attempts}")
            
            # Try each password length
            for length in range(1, max_length + 1):
                print(f"[*] Trying passwords of length {length}...")
                
                for combo in itertools.product(chars, repeat=length):
                    password = ''.join(combo)
                    attempt_count += 1
                    
                    # Progress indicator
                    if attempt_count % 1000 == 0:
                        print(f"[*] Attempts: {attempt_count}/{total_attempts}")
                    
                    try:
                        # Create a temporary directory for extraction
                        with tempfile.TemporaryDirectory() as temp_dir:
                            # Try to extract the file with this password
                            zf.extract(target_file, path=temp_dir, pwd=password.encode('utf-8'))
                            print(f"[+] SUCCESS! Password found: '{password}'")
                            print(f"[+] Total attempts: {attempt_count}")
                            return password
                            
                    except (RuntimeError, zipfile.BadZipFile):
                        # Wrong password, continue
                        continue
                    except Exception as e:
                        # Other errors (file permissions, etc.)
                        print(f"[!] Unexpected error with password '{password}': {e}")
                        continue
            
            print(f"[-] Password not found after {attempt_count} attempts")
            print(f"[-] Consider increasing max_length or checking if the file is actually password-protected")
            return None
            
    except zipfile.BadZipFile:
        print(f"[-] Invalid ZIP file: {zip_path}")
        return None
    except Exception as e:
        print(f"[-] Error opening ZIP file: {e}")
        return None

def extract_with_password(zip_path, password, output_dir="extracted"):
    """
    Extract all files from a password-protected ZIP using the found password.
    """
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            os.makedirs(output_dir, exist_ok=True)
            zf.extractall(path=output_dir, pwd=password.encode('utf-8'))
            print(f"[+] All files extracted to: {output_dir}")
    except Exception as e:
        print(f"[-] Error extracting files: {e}")

# Example usage
if __name__ == "__main__":
    zip_file = "Secret-Brute.zip"
    target_file = "Secret-Brute/Flag.txt"  # Fixed path
    
    # Find the password
    found_password = brute_force_zip(
        zip_path=zip_file,
        target_file=target_file,  # Set to None to auto-detect
        max_length=3
    )
    
    # If password found, extract all files
    if found_password:
        extract_with_password(zip_file, found_password)
        print(f"[+] Use password '{found_password}' to access the ZIP file")
